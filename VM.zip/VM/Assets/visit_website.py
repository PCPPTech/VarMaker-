import webbrowser

def OpenWebsite():
    url = "https://varmakerblog.wordpress.com"
    new = 1
    webbrowser.open(url, new=new)