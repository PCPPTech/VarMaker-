from tkinter import *

class HelpKit:
    def __init__(self, root_name, *widgets):
        self.root_name = root_name
        self.widgets = widgets
    
    def create_rounded_button(self):
        pass